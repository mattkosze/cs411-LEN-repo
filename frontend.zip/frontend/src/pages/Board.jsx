import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { CONDITION_BOARDS, api } from '../services/api'
import PostForm from '../components/PostForm'
import './Board.css'

function Board() {
  const { groupId } = useParams()
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [showPostForm, setShowPostForm] = useState(false)
  const board = CONDITION_BOARDS.find(b => b.id === parseInt(groupId))

  useEffect(() => {
    loadPosts()
  }, [groupId])

  const loadPosts = async () => {
    setLoading(true)
    setError(null)
    try {
      const data = await api.getPosts(parseInt(groupId))
      setPosts(data || [])
    } catch (err) {
      console.error('Error loading posts:', err)
      // Handle network errors more gracefully
      if (err.message.includes('Unable to connect')) {
        setError('Unable to connect to the server. Please make sure the backend is running.')
      } else {
        setError(err.message || 'Failed to load posts')
      }
    } finally {
      setLoading(false)
    }
  }

  const handlePostCreated = (newPost) => {
    setPosts([newPost, ...posts])
    setShowPostForm(false)
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now - date
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMs / 3600000)
    const diffDays = Math.floor(diffMs / 86400000)

    if (diffMins < 1) return 'just now'
    if (diffMins < 60) return `${diffMins} ${diffMins === 1 ? 'minute' : 'minutes'} ago`
    if (diffHours < 24) return `${diffHours} ${diffHours === 1 ? 'hour' : 'hours'} ago`
    if (diffDays < 7) return `${diffDays} ${diffDays === 1 ? 'day' : 'days'} ago`
    return date.toLocaleDateString()
  }

  if (!board) {
    return (
      <div className="board-error">
        <h2>Board not found</h2>
        <p>The requested board does not exist.</p>
        <Link to="/" className="btn-primary">Back to Home</Link>
      </div>
    )
  }

  return (
    <div className="board">
      <div className="board-header">
        <Link to="/" className="back-link">← Back to boards</Link>
        <div className="board-title-section">
          <div>
            <h1>{board.name}</h1>
          </div>
        </div>
        <button
          className="btn-primary"
          onClick={() => setShowPostForm(!showPostForm)}
        >
          {showPostForm ? 'Cancel' : '+ New Post'}
        </button>
      </div>

      {showPostForm && (
        <div className="post-form-container">
          <PostForm
            groupId={parseInt(groupId)}
            onPostCreated={handlePostCreated}
            onCancel={() => setShowPostForm(false)}
          />
        </div>
      )}

      {loading ? (
        <div className="loading-container">
          <div className="spinner"></div>
          <p>Loading posts...</p>
        </div>
      ) : error ? (
        <div className="error-message">
          <p>Error: {error}</p>
          <button className="btn-secondary" onClick={loadPosts}>Try Again</button>
        </div>
      ) : posts.length === 0 ? (
        <div className="empty-state">
          <p>No posts yet. Be the first to share something!</p>
        </div>
      ) : (
        <div className="posts-list">
          {posts.map((post) => (
            <article key={post.id} className="post-card">
              <div className="post-header">
                <div className="post-author">
                  <span className="author-name">
                    {post.author.isanonymous ? 'Anonymous' : post.author.display_name}
                  </span>
                  {post.author.role !== 'user' && (
                    <span className={`author-role role-${post.author.role}`}>
                      {post.author.role}
                    </span>
                  )}
                </div>
                <time className="post-time" dateTime={post.createdat}>
                  {formatDate(post.createdat)}
                </time>
              </div>
              <div className="post-content">
                {post.content.split('\n').map((paragraph, idx) => (
                  <p key={idx}>{paragraph || '\u00A0'}</p>
                ))}
              </div>
              {post.status !== 'active' && (
                <div className="post-status">
                  Status: <span className={`status-${post.status}`}>{post.status}</span>
                </div>
              )}
            </article>
          ))}
        </div>
      )}
    </div>
  )
}

export default Board
